import { useEffect, useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Services from './components/Services';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';

export default function App() {
  const [activeSection, setActiveSection] = useState('home');

  // Multi-Section Intersection tracking to update navbar links dynamically
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'about', 'skills', 'projects', 'services', 'contact'];
      const scrollPosition = window.scrollY + 200; // Offset for accuracy

      for (const sectionId of sections) {
        const element = document.getElementById(sectionId);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleScrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  return (
    <div id="portfolio-app-root" className="min-h-screen bg-space-black text-gray-200 font-sans antialiased overflow-x-hidden selection:bg-electric-violet/30 selection:text-white">
      {/* Premium Ambient Layout Background Layer */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-100px] left-[-100px] w-[500px] h-[500px] bg-[#8B5CF6]/20 rounded-full filter blur-[120px]" />
        <div className="absolute bottom-[-100px] right-[-100px] w-[500px] h-[500px] bg-[#3B82F6]/20 rounded-full filter blur-[120px]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[300px] bg-[#EC4899]/5 rounded-full filter blur-[150px] rotate-12" />
      </div>

      {/* Interactive Sticky Floating Navbar */}
      <Navbar activeSection={activeSection} />

      {/* Main Structural Flow */}
      <main className="relative z-10 w-full flex flex-col">
        {/* Hero Area */}
        <Hero
          onExploreProjects={() => handleScrollToSection('projects')}
          onContactMe={() => handleScrollToSection('contact')}
        />

        {/* About Profile Summary */}
        <About />

        {/* Dynamic Skills Meter grids */}
        <Skills />

        {/* Projects Grid Panel */}
        <Projects />

        {/* Services / Capabilities offer */}
        <Services />

        {/* Testimonials Review Slider */}
        <Testimonials />

        {/* Premium Form submission catalog */}
        <Contact />
      </main>

      {/* Footnote details */}
      <Footer />
    </div>
  );
}
