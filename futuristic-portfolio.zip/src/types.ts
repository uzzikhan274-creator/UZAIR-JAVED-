export interface Project {
  id: string;
  title: string;
  description: string;
  extendedDescription: string;
  image: string;
  tags: string[];
  demoUrl: string;
  githubUrl: string;
  featured: boolean;
  metrics?: string;
  category: string;
}

export interface Skill {
  name: string;
  iconName: string; // we'll map this to Lucide icons dynamically
  level: number; // 0-100 percentage
  description: string;
}

export interface SkillCategory {
  title: string;
  skills: Skill[];
}

export interface ExperienceItem {
  id: string;
  role: string;
  company: string;
  logoLetter: string;
  period: string;
  description: string;
  highlights: string[];
  type: 'job' | 'freelance' | 'education';
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
  gradient: string;
  features: string[];
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  company: string;
  image: string;
  content: string;
  rating: number;
}
