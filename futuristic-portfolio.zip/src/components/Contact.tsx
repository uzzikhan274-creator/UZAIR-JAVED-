import React, { useState } from 'react';
import { Mail, Phone, MapPin, CheckCircle2, Send, Github, Linkedin, Twitter, Dribbble, Instagram, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { portfolioOwner } from '../data';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;

    setIsSubmitting(true);
    // Simulate real high-fidelity submission state
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      setFormData({ name: '', email: '', subject: '', message: '' });
    }, 1800);
  };

  const socialLinks = [
    { icon: Github, href: portfolioOwner.githubUrl, id: 'git', color: 'hover:text-[#FAFAFA]', glow: 'rgba(250,250,250,0.15)' },
    { icon: Linkedin, href: portfolioOwner.linkedinUrl, id: 'lnk', color: 'hover:text-[#0077B5]', glow: 'rgba(0,119,181,0.15)' },
    { icon: Twitter, href: portfolioOwner.twitterUrl, id: 'twt', color: 'hover:text-[#1DA1F2]', glow: 'rgba(29,161,242,0.15)' },
    { icon: Dribbble, href: portfolioOwner.dribbbleUrl, id: 'drb', color: 'hover:text-[#EA4C89]', glow: 'rgba(234,76,137,0.15)' },
    { icon: Instagram, href: portfolioOwner.instagramUrl, id: 'ins', color: 'hover:text-[#E1306C]', glow: 'rgba(225,48,108,0.15)' },
  ];

  const contactInfos = [
    { icon: Mail, label: 'Main Email Catalyst', value: portfolioOwner.email, href: `mailto:${portfolioOwner.email}` },
    { icon: Phone, label: 'Secure Mobile Hotlink', value: portfolioOwner.phone, href: `tel:${portfolioOwner.phone}` },
    { icon: MapPin, label: 'Workbase Location', value: portfolioOwner.location, href: '#' },
  ];

  return (
    <section
      id="contact"
      className="relative py-[80px] overflow-hidden bg-space-black"
    >
      <div className="absolute inset-0 bg-grid-pattern opacity-30 pointer-events-none" />

      {/* Glow Backdrops */}
      <div className="absolute top-[20%] left-0 w-[450px] h-[450px] bg-electric-violet/10 rounded-full filter blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[20%] right-0 w-[400px] h-[400px] bg-neon-blue/10 rounded-full filter blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        
        {/* Section Heading */}
        <div id="contact-section-heading" className="flex flex-col items-center text-center gap-4 mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#3B82F6]/15 border border-[#3B82F6]/30">
            <span className="w-1.5 h-1.5 rounded-full bg-[#3B82F6] animate-ping" />
            <span className="text-xs font-mono font-medium tracking-wide text-[#3B82F6] uppercase">
              SECURE SECRETS COMPILER
            </span>
          </div>

          <h2 className="font-display font-extrabold text-3xl sm:text-5xl tracking-tight text-white leading-tight">
            Initiate Contact Sync
          </h2>
          <p className="font-sans text-gray-400 text-base sm:text-lg max-w-xl">
            Whether you are planning a SaaS rebuild or seeking a consulting partner, send a message to synchronise channels.
          </p>
        </div>

        {/* Form and info row */}
        <div id="contact-grid-wrapper" className="grid grid-cols-1 lg:grid-cols-12 gap-12 text-left">
          
          {/* Left Column: Coordinates & Information */}
          <motion.div
            id="contact-info-left"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-5 flex flex-col justify-between gap-10"
          >
            <div className="flex flex-col gap-6">
              <h3 className="font-display font-black text-2xl sm:text-3xl text-white">
                Contact Stacks
              </h3>
              <p className="font-sans text-sm sm:text-base text-gray-400 leading-relaxed max-w-md">
                Interested in high-fidelity visual UI grids or custom layout structures? Submit our messaging form or reach out directly on channels below. My secure gateway has a typical latency of less than 4 hours.
              </p>

              {/* Secure Info list */}
              <div className="flex flex-col gap-5 mt-4">
                {contactInfos.map((info, idx) => {
                  const Icon = info.icon;
                  return (
                    <a
                      key={idx}
                      id={`contact-info-link-${idx}`}
                      href={info.href}
                      className="group flex items-start gap-4 p-4 rounded-2xl bg-white/[0.01] border border-white/5 hover:border-neon-blue/30 hover:bg-white/[0.02] transition-colors"
                    >
                      <div className="p-3 rounded-xl bg-white/5 text-gray-400 group-hover:bg-neon-blue/15 group-hover:text-neon-blue transition-colors mt-0.5">
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="flex flex-col">
                        <span className="font-mono text-[10px] text-gray-500 uppercase tracking-widest leading-none mb-1">
                          {info.label}
                        </span>
                        <span className="font-sans text-sm sm:text-base text-gray-300 font-semibold group-hover:text-white transition-colors">
                          {info.value}
                        </span>
                      </div>
                    </a>
                  );
                })}
              </div>
            </div>

            {/* Social Network Handlers */}
            <div className="flex flex-col gap-4">
              <span className="font-mono text-[10px] text-gray-500 uppercase tracking-widest text-left">
                Secured Handles Connections
              </span>
              <div id="contact-social-row" className="flex items-center gap-3">
                {socialLinks.map((social) => {
                  const Icon = social.icon;
                  return (
                    <a
                      key={social.id}
                      id={`social-link-${social.id}`}
                      href={social.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`p-3.5 rounded-xl bg-white/5 border border-white/5 text-gray-400 transition-all duration-300 ${social.color} hover:border-white/20`}
                      style={{
                        boxShadow: `0 0 10px transparent`,
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.boxShadow = `0 0 15px ${social.glow}`;
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.boxShadow = '0 0 10px transparent';
                      }}
                    >
                      <Icon className="w-5 h-5" />
                    </a>
                  );
                })}
              </div>
            </div>

          </motion.div>

          {/* Right Column: Premium Contact Form */}
          <motion.div
            id="contact-form-right"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-7"
          >
            <div className="relative frosted-card-premium p-6 sm:p-10 rounded-[32px] border-white/20 shadow-[0_20px_50px_rgba(0,0,0,0.45)] flex flex-col items-stretch">
              
              {/* Corner decorative light element */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-neon-blue/15 to-transparent filter blur-2xl pointer-events-none" />

              <AnimatePresence mode="wait">
                {!isSubmitted ? (
                  <motion.form
                    id="contact-form-node"
                    initial={{ opacity: 1 }}
                    exit={{ opacity: 0, y: -20 }}
                    onSubmit={handleFormSubmit}
                    className="flex flex-col gap-5 w-full"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      {/* Name input */}
                      <div className="flex flex-col items-start gap-1.5">
                        <label htmlFor="form-name" className="font-mono text-[10px] text-gray-500 tracking-wider uppercase font-semibold">
                          Name / Company *
                        </label>
                        <input
                          required
                          type="text"
                          id="form-name"
                          name="name"
                          placeholder="Eleanor Vance"
                          value={formData.name}
                          onChange={handleInputChange}
                          className="w-full px-4.5 py-3.5 rounded-xl bg-white/[0.02] border border-white/5 text-white placeholder-gray-600 font-sans text-sm focus:outline-none focus:border-neon-blue focus:bg-white/[0.04] transition-all"
                        />
                      </div>

                      {/* Email input */}
                      <div className="flex flex-col items-start gap-1.5">
                        <label htmlFor="form-email" className="font-mono text-[10px] text-gray-500 tracking-wider uppercase font-semibold">
                          Email Address *
                        </label>
                        <input
                          required
                          type="email"
                          id="form-email"
                          name="email"
                          placeholder="eleanor@auravax.io"
                          value={formData.email}
                          onChange={handleInputChange}
                          className="w-full px-4.5 py-3.5 rounded-xl bg-white/[0.02] border border-white/5 text-white placeholder-gray-600 font-sans text-sm focus:outline-none focus:border-neon-blue focus:bg-white/[0.04] transition-all"
                        />
                      </div>
                    </div>

                    {/* Subject input */}
                    <div className="flex flex-col items-start gap-1.5">
                      <label htmlFor="form-subject" className="font-mono text-[10px] text-gray-500 tracking-wider uppercase font-semibold">
                        Subject Title
                      </label>
                      <input
                        type="text"
                        id="form-subject"
                        name="subject"
                        placeholder="SaaS Frontend Consultancy Inquiry"
                        value={formData.subject}
                        onChange={handleInputChange}
                        className="w-full px-4.5 py-3.5 rounded-xl bg-white/[0.02] border border-white/5 text-white placeholder-gray-600 font-sans text-sm focus:outline-none focus:border-neon-blue focus:bg-white/[0.04] transition-all"
                      />
                    </div>

                    {/* Message input */}
                    <div className="flex flex-col items-start gap-1.5">
                      <label htmlFor="form-message" className="font-mono text-[10px] text-gray-500 tracking-wider uppercase font-semibold">
                        Detailed Message *
                      </label>
                      <textarea
                        required
                        id="form-message"
                        name="message"
                        rows={5}
                        placeholder="Hello Alex, we are looking for interactive creative engineering patterns to reconstruct our data dashboards..."
                        value={formData.message}
                        onChange={handleInputChange}
                        className="w-full px-4.5 py-3.5 rounded-xl bg-white/[0.02] border border-white/5 text-white placeholder-gray-600 font-sans text-sm focus:outline-none focus:border-neon-blue focus:bg-white/[0.04] transition-all resize-none"
                      />
                    </div>

                    {/* Submit Button with Loading states */}
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      id="contact-form-submit-trigger"
                      className={`group mt-3 w-full py-4 px-6 rounded-xl font-display font-semibold text-sm tracking-wide flex items-center justify-center gap-2 transition-all duration-300 cursor-pointer ${
                        isSubmitting
                          ? 'bg-gradient-to-r from-neon-blue/50 to-electric-violet/50 text-white/50 cursor-not-allowed'
                          : 'bg-white text-space-black hover:bg-white/90 active:scale-95 shadow-[0_4px_25px_rgba(255,255,255,0.15)]'
                      }`}
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-5 h-5 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                          Processing Gate...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition-transform" />
                          Transmit Secure Payload
                        </>
                      )}
                    </button>
                  </motion.form>
                ) : (
                  <motion.div
                    id="contact-success-state"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ type: 'spring', damping: 20 }}
                    className="flex flex-col items-center justify-center text-center py-12 gap-5"
                  >
                    <div className="p-4 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 relative">
                      <CheckCircle2 className="w-12 h-12 animate-pulse" />
                      <div className="absolute inset-0 bg-emerald-500/20 rounded-full filter blur-xl -z-10 animate-ping [animation-duration:1.5s]" />
                    </div>

                    <div className="flex flex-col gap-2">
                      <h3 className="font-display font-extrabold text-2xl text-white">
                        Gateway Sync Achieved
                      </h3>
                      <p className="font-sans text-sm text-gray-400 max-w-xs leading-relaxed mx-auto">
                        Your message payload has been securely routed of any telemetry noise. Expect response sync coordinates shortly.
                      </p>
                    </div>

                    <button
                      onClick={() => setIsSubmitted(false)}
                      id="contact-reset-button"
                      className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full bg-white/5 hover:bg-white/10 text-xs font-mono text-gray-300 hover:text-white border border-white/15 cursor-pointer transition-colors"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      Establish New Gate
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>

            </div>
          </motion.div>

        </div>

      </div>
    </section>
  );
}
