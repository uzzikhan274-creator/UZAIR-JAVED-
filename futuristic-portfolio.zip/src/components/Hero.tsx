import { ArrowRight, Sparkles, Send, Github, Linkedin, Briefcase } from 'lucide-react';
import { motion } from 'motion/react';
import ParticleCanvas from './ParticleCanvas';

interface HeroProps {
  onExploreProjects: () => void;
  onContactMe: () => void;
}

export default function Hero({ onExploreProjects, onContactMe }: HeroProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: 'spring',
        stiffness: 100,
        damping: 18,
      },
    },
  };

  const textGradientVariants = {
    animate: {
      backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
      transition: {
        duration: 8,
        repeat: Infinity,
        ease: 'linear',
      },
    },
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-28 md:pt-20 px-4 md:px-8 bg-space-black"
    >
      {/* Background Matrix/Grid Overlay */}
      <div className="absolute inset-0 bg-grid-pattern opacity-60 pointer-events-none" />

      {/* Decorative Blur Background Blob */}
      <div className="absolute top-[10%] left-[5%] w-[450px] h-[450px] bg-[#8B5CF6]/15 rounded-full filter blur-[120px] mix-blend-screen animate-pulse pointer-events-none" />
      <div className="absolute bottom-[10%] right-[5%] w-[400px] h-[400px] bg-[#3B82F6]/15 rounded-full filter blur-[120px] mix-blend-screen animate-pulse pointer-events-none" />

      <div className="relative max-w-7xl w-full mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center z-10">
        
        {/* Left Side: Headline & Value Prop */}
        <motion.div
          id="hero-content-left"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="lg:col-span-7 flex flex-col items-start gap-6 text-left"
        >
          {/* Subtle micro tag indicating core domain */}
          <motion.div
            variants={itemVariants}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-md shadow-[0_4px_20px_rgba(139,92,246,0.15)]"
          >
            <Sparkles className="w-4 h-4 text-orange-glow animate-spin [animation-duration:5s]" />
            <span className="text-xs font-mono font-medium tracking-wide bg-gradient-to-r from-lavender-light to-white bg-clip-text text-transparent">
              FUTURISTIC DIGITAL EXCELLENCE
            </span>
          </motion.div>

          {/* Master Display Heading */}
          <motion.div variants={itemVariants} className="relative">
            <h1 id="hero-display-title" className="font-display font-bold text-4xl sm:text-5xl lg:text-7xl leading-[1.05] tracking-tight text-white">
              Crafting Digital <br />
              <span className="relative inline-block text-transparent bg-clip-text bg-gradient-to-r from-[#3B82F6] via-[#8B5CF6] via-[#EC4899] to-[#FB923C] bg-[length:300%_auto] animate-glow-flow">
                Experiences
              </span> <br />
              That Inspire.
            </h1>
          </motion.div>

          {/* Detailed value proposition, describing modern SaaS capability */}
          <motion.p
            id="hero-value-prop"
            variants={itemVariants}
            className="font-sans text-gray-400 text-base sm:text-lg lg:text-xl leading-relaxed max-w-xl"
          >
            Hi, I'm Alex. A specialized Creative Technologist building responsive, highly animated, ultra-performance user interfaces and geometric visualization panels for modern SaaS, AI, and developer tools.
          </motion.p>

          {/* Action buttons */}
          <motion.div
            id="hero-action-triggers"
            variants={itemVariants}
            className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto mt-2"
          >
            <button
              id="hero-view-projects-button"
              onClick={onExploreProjects}
              className="group relative inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-white text-space-black font-semibold tracking-wide hover:bg-white/90 active:scale-95 transition-all duration-300 shadow-[0_0_20px_rgba(255,255,255,0.2)] cursor-pointer"
            >
              View Projects
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              id="hero-contact-button"
              onClick={onContactMe}
              className="group inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full border border-white/20 hover:border-electric-violet/80 hover:bg-white/5 text-white font-medium tracking-wide active:scale-95 transition-all duration-300 cursor-pointer"
            >
              Get in Touch
              <Send className="w-4 h-4 group-hover:scale-105 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition-transform text-white/70" />
            </button>
          </motion.div>


        </motion.div>

        {/* Right Side: High fidelity flowing particle visualization stage */}
        <motion.div
          id="hero-canvas-container"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, ease: 'easeOut' }}
          className="lg:col-span-5 w-full h-[350px] sm:h-[450px] lg:h-[550px] rounded-3xl overflow-hidden glass-panel border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.5)] relative flex items-center justify-center"
        >
          {/* Glowing particle canvas itself */}
          <ParticleCanvas />

          {/* Aesthetic overlays giving detailed design info without clutter */}
          <div className="absolute top-4 left-4 p-3 rounded-xl bg-space-black/80 border border-white/5 backdrop-blur-md flex items-center gap-2 pointer-events-none">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-mono text-[10px] text-gray-400 tracking-wider">ENGINE_OK // 60_FPS</span>
          </div>

          <div className="absolute bottom-4 right-4 p-3 rounded-xl bg-space-black/80 border border-white/5 backdrop-blur-md pointer-events-none flex flex-col items-end gap-0.5">
            <span className="font-mono text-[9px] text-gray-500 tracking-wide uppercase">Stage Grid Projection</span>
            <span className="font-mono text-[10px] text-lavender-light font-medium tracking-wider">SECURE CONSOLE</span>
          </div>
        </motion.div>

      </div>
    </section>
  );
}
