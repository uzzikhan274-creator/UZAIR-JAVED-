import { useEffect, useState } from 'react';
import { User2 } from 'lucide-react';
import { motion } from 'motion/react';
import { portfolioOwner } from '../data';

// Helper component for count-up animation
function CounterCard({ end, suffix = "", title, delaySec = 0 }: { end: number; suffix?: string; title: string; delaySec?: number }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    const duration = 1500; // ms
    const stepTime = Math.max(Math.floor(duration / end), 15);
    const startTime = Date.now();

    const updateCount = () => {
      const now = Date.now();
      const progress = Math.min((now - startTime) / duration, 1);
      const current = Math.floor(progress * end);
      setCount(current);

      if (progress < 1) {
        timer = setTimeout(updateCount, stepTime);
      } else {
        setCount(end);
      }
    };

    const delayTimer = setTimeout(() => {
      updateCount();
    }, delaySec * 1000);

    return () => {
      clearTimeout(delayTimer);
      clearTimeout(timer);
    };
  }, [end, delaySec]);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.5, delay: delaySec }}
      className="glass-panel p-5 rounded-2xl flex flex-col items-center justify-center text-center border-white/5 hover:border-electric-violet/30 transition-all duration-300 shadow-[0_4px_25px_rgba(0,0,0,0.3)] group cursor-default"
    >
      <div className="text-3xl sm:text-4xl font-display font-extrabold bg-gradient-to-r from-neon-blue via-electric-violet to-soft-pink bg-clip-text text-transparent group-hover:scale-105 transition-transform">
        {count}
        {suffix}
      </div>
      <div className="text-xs sm:text-sm text-gray-400 font-sans font-medium mt-1 uppercase tracking-wider">
        {title}
      </div>
    </motion.div>
  );
}

export default function About() {
  const avatarPath = '/src/assets/images/avatar_developer_1781226322702.jpg';

  return (
    <section
      id="about"
      className="relative py-[80px] overflow-hidden bg-space-black"
    >
      <div className="absolute inset-0 bg-grid-pattern opacity-30 pointer-events-none" />

      {/* Glow Blob */}
      <div className="absolute top-[30%] right-[10%] w-[350px] h-[350px] bg-electric-violet/15 rounded-full filter blur-[110px] pointer-events-none" />
      <div className="absolute bottom-[20%] left-[5%] w-[300px] h-[300px] bg-neon-blue/15 rounded-full filter blur-[90px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
          
          {/* Left Side: Generated Avatar Photo & Frame */}
          <motion.div
            id="about-visuals-left"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="lg:col-span-5 flex flex-col items-center justify-center"
          >
            <div className="relative w-full max-w-[360px] aspect-square rounded-3xl overflow-hidden shadow-[0_20px_55px_rgba(0,0,0,0.6)] group">
              
              {/* Spinning Neon Aura Ring */}
              <div className="absolute inset-0 bg-gradient-to-tr from-neon-blue via-electric-violet to-soft-pink opacity-50 p-[3px] rounded-3xl animate-glow-flow">
                <div className="w-full h-full bg-space-black rounded-3xl overflow-hidden relative">
                  {/* Avatar image */}
                  <img
                    id="developer-avatar-img"
                    src={avatarPath}
                    alt={portfolioOwner.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover grayscale brightness-90 contrast-110 group-hover:scale-105 group-hover:grayscale-0 transition-all duration-700"
                  />
                </div>
              </div>

              {/* Grid Tech overlay */}
              <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none mix-blend-overlay" />

              {/* Bottom tag block inside visual */}
              <div className="absolute bottom-4 inset-x-4 p-3 bg-space-black/80 backdrop-blur-md rounded-2xl border border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <User2 className="w-4 h-4 text-electric-violet" />
                  <span className="font-mono text-xs text-white">Alex Vance</span>
                </div>
                <span className="font-mono text-[9px] text-gray-500 uppercase tracking-widest bg-white/5 px-2 py-1 rounded">CREATIVE TECH</span>
              </div>
            </div>

            {/* Micro decorative coordinates tag */}
            <div className="mt-4 flex items-center gap-2 text-gray-500 font-mono text-[10px] tracking-wide uppercase select-none">
              <span>LAT: 37.7749° N</span>
              <span className="w-1.5 h-1.5 rounded-full bg-white/10" />
              <span>LON: 122.4194° W</span>
            </div>
          </motion.div>

          {/* Right Side: Copywriting & Milestones */}
          <motion.div
            id="about-content-right"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="lg:col-span-7 flex flex-col items-start text-left gap-6"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-electric-violet/10 border border-electric-violet/20">
              <span className="w-1.5 h-1.5 rounded-full bg-electric-violet" />
              <span className="text-xs font-mono font-medium tracking-wide text-electric-violet uppercase">
                BIOGRAPHY & FOCUS
              </span>
            </div>

            <h2 id="about-section-title" className="font-display font-extrabold text-3xl sm:text-5xl tracking-tight text-white leading-tight">
              A Blend of Pure Engineering <br />
              & <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-electric-violet">Visual Experience</span>.
            </h2>

            <p id="about-summary-description" className="font-sans text-gray-400 text-base sm:text-lg leading-relaxed">
              {portfolioOwner.aboutSummary}
            </p>

            {/* Counters Grid section */}
            <div id="about-counters-grid" className="grid grid-cols-3 gap-4 w-full my-4">
              <CounterCard end={portfolioOwner.experienceYears} suffix="+" title="Years Exp" delaySec={0.1} />
              <CounterCard end={portfolioOwner.projectsCompleted} suffix="+" title="SaaS Done" delaySec={0.2} />
              <CounterCard end={portfolioOwner.happyClients} suffix="+" title="Partners" delaySec={0.3} />
            </div>

          </motion.div>

        </div>

      </div>
    </section>
  );
}
