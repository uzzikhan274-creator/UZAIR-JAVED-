import React, { useEffect, useRef, useState } from 'react';

/**
 * High-performance Canvas particle and flowing lines visualization
 * Custom designed to evoke premium tech, SaaS, and AI start-up waves.
 */
export default function ParticleCanvas() {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0, active: false });

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = 0;
    let height = 0;

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: entryWidth, height: entryHeight } = entry.contentRect;
        width = entryWidth;
        height = entryHeight;
        canvas.width = entryWidth * window.devicePixelRatio;
        canvas.height = entryHeight * window.devicePixelRatio;
        canvas.style.width = `${entryWidth}px`;
        canvas.style.height = `${entryHeight}px`;
        ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
      }
    });

    resizeObserver.observe(container);

    // Dynamic state
    const particlesCount = 45;
    const particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      color: string;
      alpha: number;
      pulseRate: number;
      angle: number;
      speed: number;
    }> = [];

    const colors = [
      'rgba(139, 92, 246, ', // electric violet
      'rgba(59, 130, 246, ',  // neon blue
      'rgba(236, 72, 153, ',  // soft pink
      'rgba(251, 146, 60, ',  // orange highlight
    ];

    // Seed particles
    const initParticles = () => {
      particles.length = 0;
      const w = width || container.clientWidth || 500;
      const h = height || container.clientHeight || 500;
      for (let i = 0; i < particlesCount; i++) {
        particles.push({
          x: Math.random() * w,
          y: Math.random() * h,
          vx: (Math.random() - 0.5) * 0.4,
          vy: (Math.random() - 0.5) * 0.4,
          size: Math.random() * 2.8 + 1,
          color: colors[Math.floor(Math.random() * colors.length)],
          alpha: Math.random() * 0.5 + 0.3,
          pulseRate: 0.01 + Math.random() * 0.02,
          angle: Math.random() * Math.PI * 2,
          speed: 0.2 + Math.random() * 0.3
        });
      }
    };

    // First initializer call
    setTimeout(() => {
      initParticles();
    }, 100);

    const orbitPoints = Array.from({ length: 4 }).map((_, i) => ({
      angle: (i * Math.PI) / 2,
      radius: 120 + i * 40,
      speed: 0.003 - i * 0.0005,
      centerX: 0.5,
      centerY: 0.5,
    }));

    // Main render loop
    const render = () => {
      ctx.clearRect(0, 0, width, height);

      const centerW = width / 2;
      const centerH = height / 2;

      // Draw elegant orbits/lines inspired by modern tech screens
      orbitPoints.forEach((orbit, index) => {
        orbit.angle += orbit.speed;
        const currentRadiusX = orbit.radius * 1.5;
        const currentRadiusY = orbit.radius * 0.8;

        // Draw orbital shadow pattern
        ctx.beginPath();
        ctx.ellipse(centerW, centerH, currentRadiusX, currentRadiusY, Math.PI / 12, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(139, 92, 246, ${0.05 - index * 0.01})`;
        ctx.lineWidth = 1;
        ctx.stroke();

        // Draw animated orbiting nodes
        const activeX = centerW + Math.cos(orbit.angle) * currentRadiusX;
        const activeY = centerH + Math.sin(orbit.angle) * currentRadiusY;

        ctx.beginPath();
        ctx.arc(activeX, activeY, 3 + index * 0.5, 0, Math.PI * 2);
        ctx.fillStyle = index % 2 === 0 ? '#3B82F6' : '#EC4899';
        ctx.shadowColor = index % 2 === 0 ? '#3B82F6' : '#EC4899';
        ctx.shadowBlur = 12;
        ctx.fill();
        ctx.shadowBlur = 0; // reset
      });

      // Update and draw floating particles & dynamic connections
      particles.forEach((p, i) => {
        p.angle += p.pulseRate;
        const currentAlpha = p.alpha + Math.sin(p.angle) * 0.15;

        // Vector movement
        p.x += p.vx + Math.sin(p.angle) * 0.05;
        p.y += p.vy + Math.cos(p.angle) * 0.05;

        // Boundary bounce
        if (p.x < 0 || p.x > width) p.vx *= -1;
        if (p.y < 0 || p.y > height) p.vy *= -1;

        // Draw particle glow element
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color + currentAlpha + ')';
        ctx.fill();

        // Check distance to cursor for magnetic lines
        if (mousePos.active) {
          const dx = p.x - mousePos.x;
          const dy = p.y - mousePos.y;
          const dist = Math.hypot(dx, dy);
          if (dist < 120) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(mousePos.x, mousePos.y);
            ctx.strokeStyle = `rgba(139, 92, 246, ${0.15 * (1 - dist / 120)})`;
            ctx.lineWidth = 0.8;
            ctx.stroke();
          }
        }

        // Draw connections between nearby particles (proximity network layout)
        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dx = p.x - p2.x;
          const dy = p.y - p2.y;
          const dist = Math.hypot(dx, dy);

          if (dist < 100) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = `rgba(255, 255, 255, ${0.05 * (1 - dist / 100)})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      resizeObserver.disconnect();
      cancelAnimationFrame(animationFrameId);
    };
  }, [mousePos]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    setMousePos({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
      active: true,
    });
  };

  const handleMouseLeave = () => {
    setMousePos((prev) => ({ ...prev, active: false }));
  };

  return (
    <div
      ref={containerRef}
      id="hero-particle-stage"
      className="relative w-full h-full select-none cursor-crosshair overflow-hidden"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      {/* Background neon radial glow maps */}
      <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-[350px] h-[350px] bg-gradient-to-tr from-electric-violet to-transparent opacity-20 filter blur-[80px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 translate-x-1/2 translate-y-1/2 w-[300px] h-[300px] bg-gradient-to-bl from-neon-blue to-transparent opacity-20 filter blur-[80px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[220px] h-[220px] bg-gradient-to-r from-soft-pink to-transparent opacity-10 filter blur-[60px] pointer-events-none" />

      {/* Actual hardware Canvas layer */}
      <canvas ref={canvasRef} className="absolute inset-0 block w-full h-full" />
    </div>
  );
}
