import { Code, Palette, Sparkles, Check } from 'lucide-react';
import { motion } from 'motion/react';
import { servicesData } from '../data';

const getIcon = (name: string) => {
  switch (name) {
    case 'Code': return Code;
    case 'Palette': return Palette;
    case 'Sparkles': return Sparkles;
    default: return Code;
  }
};

export default function Services() {
  return (
    <section
      id="services"
      className="relative py-[80px] overflow-hidden bg-space-black"
    >
      <div className="absolute inset-0 bg-grid-pattern opacity-30 pointer-events-none" />

      {/* Background radial orbs */}
      <div className="absolute top-[15%] right-[10%] w-[400px] h-[400px] bg-soft-pink/10 rounded-full filter blur-[110px] pointer-events-none" />
      <div className="absolute bottom-[10%] left-[5%] w-[350px] h-[350px] bg-electric-violet/15 rounded-full filter blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        
        {/* Section Heading */}
        <div id="services-section-heading" className="flex flex-col items-center text-center gap-4 mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-glow/15 border border-orange-glow/30">
            <span className="w-1.5 h-1.5 rounded-full bg-orange-glow" />
            <span className="text-xs font-mono font-medium tracking-wide text-orange-glow uppercase">
              PROFESSIONAL WORK SERVICES
            </span>
          </div>

          <h2 className="font-display font-extrabold text-3xl sm:text-5xl tracking-tight text-white leading-tight">
            Consultancy & Systems Integration
          </h2>
          <p className="font-sans text-gray-400 text-base sm:text-lg max-w-xl">
            Bespoke interactive systems built to deliver state excellence, high scalability, and seamless user adoption for fast-growing companies.
          </p>
        </div>

        {/* Services Cards Grid */}
        <div id="services-grid" className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {servicesData.map((service, index) => {
            const Icon = getIcon(service.iconName);
            return (
              <motion.div
                key={service.id}
                id={`service-card-${service.id}`}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.6, delay: index * 0.15 }}
                className="group relative flex flex-col items-start text-left frosted-card-premium p-6 sm:p-8 rounded-[32px] border-white/10 hover:border-white/25 shadow-[0_10px_35px_rgba(0,0,0,0.3)] transition-all duration-500 overflow-hidden"
              >
                {/* Custom Gradient Background Glow on Hover */}
                <span className={`absolute -inset-px rounded-[32px] bg-gradient-to-r ${service.gradient} opacity-0 group-hover:opacity-100 p-0.5 transition-opacity duration-500 -z-10`} />
                
                {/* Background tint layer inside border to ensure legible typography */}
                <div className="absolute inset-0 bg-space-black/40 group-hover:bg-space-black/25 rounded-[32px] -z-10 transition-colors" />

                {/* Service Icon with a glowing backdrop */}
                <div className="mb-6 relative">
                  <div className={`p-4 rounded-2xl bg-gradient-to-r ${service.gradient} text-white shadow-lg group-hover:scale-105 transition-transform duration-350`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  {/* Outer glowing reflection blob */}
                  <div className={`absolute inset-0 bg-gradient-to-r ${service.gradient} rounded-2xl opacity-40 filter blur-xl -z-20 scale-125 group-hover:opacity-60 transition-opacity`} />
                </div>

                {/* Service Copywriting */}
                <h3 className="font-display font-extrabold text-xl sm:text-2xl text-white mb-3">
                  {service.title}
                </h3>

                <p className="font-sans text-gray-400 text-sm sm:text-base leading-relaxed mb-6">
                  {service.description}
                </p>

                {/* Key Technical Features checklist */}
                <div className="flex flex-col gap-3 w-full border-t border-white/5 pt-6 mt-auto">
                  {service.features.map((feat, fIdx) => (
                    <div
                      key={fIdx}
                      id={`service-feat-${service.id}-${fIdx}`}
                      className="flex items-center gap-2"
                    >
                      <div className="p-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                        <Check className="w-3.5 h-3.5" />
                      </div>
                      <span className="font-sans text-xs sm:text-sm text-gray-300 font-medium">
                        {feat}
                      </span>
                    </div>
                  ))}
                </div>

              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
