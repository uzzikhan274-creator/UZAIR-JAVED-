import { useState } from 'react';
import { ExternalLink, Github, FolderKanban, Star } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { projectsData } from '../data';

export default function Projects() {
  const [activeFilter, setActiveFilter] = useState<'All' | 'SaaS Platform' | 'Creative Coding' | 'DevTools' | 'AI Infrastructure'>('All');

  const filters: Array<'All' | 'SaaS Platform' | 'Creative Coding' | 'DevTools' | 'AI Infrastructure'> = [
    'All', 'SaaS Platform', 'Creative Coding', 'DevTools', 'AI Infrastructure'
  ];

  const filteredProjects = activeFilter === 'All'
    ? projectsData
    : projectsData.filter(proj => proj.category === activeFilter);

  return (
    <section
      id="projects"
      className="relative py-[80px] overflow-hidden bg-space-black"
    >
      <div className="absolute inset-0 bg-grid-pattern opacity-30 pointer-events-none" />

      {/* Decorative Blur Background Blob */}
      <div className="absolute top-[40%] right-0 w-[450px] h-[450px] bg-[#EC4899]/10 rounded-full filter blur-[120px] pointer-events-none animate-pulse" />
      <div className="absolute bottom-[10%] left-0 w-[400px] h-[400px] bg-[#3B82F6]/10 rounded-full filter blur-[100px] pointer-events-none animate-pulse" />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        
        {/* Section Heading */}
        <div id="projects-section-header" className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="flex flex-col items-start gap-3.5 text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neon-blue/15 border border-neon-blue/30">
              <span className="w-1.5 h-1.5 rounded-full bg-neon-blue" />
              <span className="text-xs font-mono font-medium tracking-wide text-neon-blue uppercase">
                SHOWCASE & EXPERIMENTS
              </span>
            </div>

            <h2 className="font-display font-extrabold text-3xl sm:text-5xl tracking-tight text-white leading-tight">
              Featured Web Artworks
            </h2>
            <p className="font-sans text-gray-400 text-base sm:text-lg max-w-xl">
              Immersive, high-performance web systems combining interactive geometry with highly integrated developer workflows.
            </p>
          </div>

          {/* Micro Stat banner on projects */}
          <div className="hidden lg:flex items-center gap-2 px-4 py-3 rounded-2xl bg-white/[0.02] border border-white/5 pointer-events-none self-end">
            <FolderKanban className="w-4 h-4 text-orange-glow animate-bounce" />
            <span className="font-mono text-xs text-gray-400 tracking-wide uppercase">
              Production Build Verified
            </span>
          </div>
        </div>

        {/* Dynamic Nav Filters - SaaS themed filter Pills */}
        <div id="project-filters-row" className="flex flex-wrap items-center justify-start gap-2.5 mb-12 border-b border-white/5 pb-6">
          {filters.map((filter) => {
            const active = activeFilter === filter;
            return (
              <button
                key={filter}
                id={`project-filter-${filter.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={() => setActiveFilter(filter)}
                className={`relative px-4 py-2 rounded-full text-xs sm:text-sm font-sans font-semibold tracking-wide transition-all cursor-pointer ${
                  active
                    ? 'text-white'
                    : 'text-gray-400 hover:text-white bg-white/5 border border-white/10 hover:bg-white/10'
                }`}
              >
                {active && (
                  <motion.span
                    layoutId="activeFilterIndicator"
                    className="absolute inset-0 bg-gradient-to-r from-neon-blue to-electric-violet rounded-full opacity-100 -z-10"
                    transition={{ type: 'spring', stiffness: 350, damping: 25 }}
                  />
                )}
                {filter}
              </button>
            );
          })}
        </div>

        {/* Interactive Grid with layout animations */}
        <motion.div
          layout
          id="project-masonry-grid"
          className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start"
        >
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project, index) => {
              return (
                <motion.div
                  key={project.id}
                  layout
                  id={`project-card-${project.id}`}
                  initial={{ opacity: 0, scale: 0.92, y: 30 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.92, y: 15 }}
                  transition={{ duration: 0.5, ease: 'easeInOut' }}
                  className="group relative flex flex-col frosted-card-premium rounded-[32px] overflow-hidden transition-all duration-500 hover:border-white/25"
                >
                  {/* Decorative Glowing Border Back Drop */}
                  <div className="absolute inset-0 bg-gradient-to-tr from-neon-blue via-electric-violet to-soft-pink opacity-0 group-hover:opacity-15 transition-opacity duration-500 pointer-events-none" />

                  {/* Project Image Frame (browser dashboard lookalike mockup) */}
                  <div className="relative aspect-video w-full overflow-hidden bg-space-black border-b border-white/5">
                    {/* Browser Control Mock Header */}
                    <div className="absolute top-0 inset-x-0 h-8 bg-space-black/90 backdrop-blur-md border-b border-white/5 px-4 flex items-center justify-between z-10 pointer-events-none">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                      </div>
                      <span className="font-mono text-[9px] text-gray-500 tracking-widest bg-white/5 px-3 py-0.5 rounded">
                        https://{project.id}.vance.io
                      </span>
                      <div className="w-8" />
                    </div>

                    {/* Actual image */}
                    <img
                      src={project.image}
                      alt={project.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover pt-8 scale-100 group-hover:scale-[1.03] transition-transform duration-700 brightness-95"
                    />

                    {/* Left category float badge */}
                    <div className="absolute bottom-4 left-4 px-3 py-1 bg-space-black/90 backdrop-blur-md rounded-lg border border-white/10 flex items-center gap-1.5 pointer-events-none z-10 animate-bounce [animation-duration:4s]">
                      <span className="w-1.5 h-1.5 rounded-full bg-electric-violet" />
                      <span className="font-mono text-[10px] font-semibold text-gray-300 tracking-wider">
                        {project.category}
                      </span>
                    </div>

                    {/* Metrics Float Badge if present */}
                    {project.metrics && (
                      <div className="absolute bottom-4 right-4 px-3 py-1 bg-space-black/90 backdrop-blur-md rounded-lg border border-white/10 flex items-center gap-1.5 pointer-events-none z-10 font-mono text-[10px] text-orange-glow font-bold tracking-wider">
                        <Star className="w-3 h-3 fill-orange-glow" />
                        {project.metrics}
                      </div>
                    )}
                  </div>

                  {/* Copywriting Section */}
                  <div className="p-6 sm:p-8 flex flex-col items-start gap-4 text-left">
                    <h3 className="font-display font-bold text-xl sm:text-2xl text-white group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-electric-violet transition-colors">
                      {project.title}
                    </h3>

                    <p className="font-sans text-gray-400 text-sm sm:text-base leading-relaxed">
                      {project.description}
                    </p>

                    <p className="font-sans text-gray-400/80 text-xs sm:text-sm line-clamp-2 italic">
                      {project.extendedDescription}
                    </p>

                    {/* Interactive tags list */}
                    <div className="flex flex-wrap items-center gap-2 mt-2 w-full">
                      {project.tags.map((tag) => (
                        <span
                          key={tag}
                          className="font-mono text-[10px] font-semibold px-2.5 py-1 rounded bg-white/5 text-gray-400 border border-white/5 tracking-wider hover:border-white/15 transition-all"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    {/* Action buttons (Live and GitHub) */}
                    <div className="flex items-center gap-3 w-full border-t border-white/5 pt-6 mt-4">
                      <a
                        href={project.demoUrl}
                        className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-white text-space-black hover:bg-white/90 font-semibold text-sm active:scale-95 transition-all cursor-pointer"
                      >
                        <ExternalLink className="w-4 h-4" />
                        Live Demo
                      </a>
                      <a
                        href={project.githubUrl}
                        className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-white border border-white/10 hover:border-white/20 font-semibold text-sm active:scale-95 transition-all cursor-pointer"
                      >
                        <Github className="w-4 h-4" />
                        Source Code
                      </a>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </motion.div>

      </div>
    </section>
  );
}
