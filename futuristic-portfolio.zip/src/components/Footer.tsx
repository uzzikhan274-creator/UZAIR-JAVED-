import { Cpu, ArrowUp, Github, Linkedin, Twitter, Instagram, Sparkles } from 'lucide-react';
import { portfolioOwner } from '../data';

export default function Footer() {
  const scrollBackToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  const menuLinks = [
    { label: 'Home', id: 'home' },
    { label: 'About', id: 'about' },
    { label: 'Skills', id: 'skills' },
    { label: 'Projects', id: 'projects' },
    { label: 'Services', id: 'services' },
    { label: 'Contact', id: 'contact' },
  ];

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  return (
    <footer
      id="main-footer"
      className="relative bg-[#040407] overflow-hidden pt-16 pb-12 border-t border-white/5"
    >
      {/* Subtle Animate Glowing Gradient Line on Top */}
      <div className="absolute top-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-neon-blue via-electric-violet via-soft-pink via-orange-glow to-transparent opacity-60 animate-glow-flow" />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10 flex flex-col gap-10">
        
        {/* Top Footer tier: Brand & Links */}
        <div id="footer-top-row" className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-10">
          
          {/* Logo & Slogan */}
          <div className="flex flex-col items-start gap-3 text-left">
            <div className="flex items-center gap-2">
              <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-tr from-neon-blue to-electric-violet text-white">
                <Cpu className="w-4 h-4" />
              </div>
              <span className="font-display font-medium text-base tracking-wider uppercase bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                ALEX<span className="font-light text-electric-violet">.VANCE</span>
              </span>
            </div>
            <p className="font-sans text-xs sm:text-sm text-gray-500 max-w-sm">
              Engineering high-contrast interactive digital interfaces for the world's most innovative technology platforms.
            </p>
          </div>

          {/* Quick Nav elements */}
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2.5">
            {menuLinks.map((link) => (
              <button
                key={link.id}
                id={`footer-link-${link.id}`}
                onClick={() => scrollToSection(link.id)}
                className="font-sans text-xs sm:text-sm text-gray-400 hover:text-white transition-colors cursor-pointer"
              >
                {link.label}
              </button>
            ))}
          </div>

        </div>

        {/* Divider line between tiers */}
        <div className="h-[1px] bg-white/5 w-full" />

        {/* Bottom Footer tier: Patents & scroll buttons */}
        <div id="footer-bottom-row" className="flex flex-col sm:flex-row items-center justify-between gap-6">
          
          {/* Copyright description */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 text-center sm:text-left text-xs text-gray-500">
            <span>© 2026 Alex Vance. All licenses reserved.</span>
            <span className="hidden sm:inline-block w-1.5 h-1.5 rounded-full bg-white/10" />
            <span className="flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-lavender-light animate-pulse" />
              Built in San Francisco Workspace
            </span>
          </div>

          {/* Scroll Back to Top Floating Trigger */}
          <button
            id="scroll-to-top-button"
            onClick={scrollBackToTop}
            className="group inline-flex items-center gap-2 p-3.5 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white border border-white/10 transition-colors cursor-pointer active:scale-95"
            aria-label="Scroll back to top"
          >
            <span className="font-mono text-[10px] uppercase tracking-widest hidden group-hover:inline-block transition-opacity">Back To Top</span>
            <ArrowUp className="w-4 h-4 group-hover:-translate-y-0.5 transition-transform" />
          </button>

        </div>

      </div>
    </footer>
  );
}
