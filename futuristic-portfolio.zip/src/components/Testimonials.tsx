import { useEffect, useState, useRef } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { testimonialsData } from '../data';

export default function Testimonials() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const totalSlides = testimonialsData.length;
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const nextSlide = () => {
    setActiveIndex((prev) => (prev === totalSlides - 1 ? 0 : prev + 1));
  };

  const prevSlide = () => {
    setActiveIndex((prev) => (prev === 0 ? totalSlides - 1 : prev - 1));
  };

  // Auto sliding trigger
  useEffect(() => {
    if (isHovered) return;
    
    timeoutRef.current = setInterval(() => {
      nextSlide();
    }, 4500);

    return () => {
      if (timeoutRef.current) clearInterval(timeoutRef.current);
    };
  }, [activeIndex, isHovered]);

  return (
    <section
      id="testimonials"
      className="relative py-[80px] overflow-hidden bg-space-black"
    >
      <div className="absolute inset-0 bg-grid-pattern opacity-30 pointer-events-none" />

      {/* Decorative Orbs */}
      <div className="absolute top-[30%] left-[5%] w-[350px] h-[350px] bg-neon-blue/10 rounded-full filter blur-[110px] pointer-events-none" />
      <div className="absolute bottom-[20%] right-[3%] w-[300px] h-[300px] bg-electric-violet/10 rounded-full filter blur-[90px] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 md:px-8 relative z-10">
        
        {/* Section Heading */}
        <div id="testimonials-heading-centered" className="flex flex-col items-center text-center gap-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-soft-pink/15 border border-soft-pink/30">
            <span className="w-1.5 h-1.5 rounded-full bg-soft-pink" />
            <span className="text-xs font-mono font-medium tracking-wide text-soft-pink uppercase">
              CLIENT TESTIMONIALS
            </span>
          </div>

          <h2 className="font-display font-extrabold text-3xl sm:text-5xl tracking-tight text-white leading-tight">
            Endorsements & Trust
          </h2>
          <p className="font-sans text-gray-400 text-base sm:text-lg max-w-xl">
            A reflection of high quality standards, reliable codes, and meticulous pixel craftsmanship across our SaaS products.
          </p>
        </div>

        {/* Carousel Slide Container */}
        <div
          id="testimonials-slider-box"
          className="relative"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={activeIndex}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.45, ease: 'easeInOut' }}
              className="frosted-card-premium p-6 sm:p-10 md:p-12 rounded-[32px] border-white/20 relative flex flex-col items-center shadow-[0_20px_50px_rgba(0,0,0,0.45)] border-l-4 border-l-electric-violet/40 text-left md:text-center mt-4"
            >
              {/* Decorative Quote Icon */}
              <Quote className="absolute top-6 right-8 w-12 h-12 text-white/[0.03] scale-125 select-none pointer-events-none" />

              {/* Star Rating row */}
              <div className="flex items-center gap-1.5 mb-6 justify-start md:justify-center">
                {Array.from({ length: testimonialsData[activeIndex].rating }).map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-orange-glow text-orange-glow animate-pulse" />
                ))}
              </div>

              {/* Review content body */}
              <blockquote className="font-sans text-lg sm:text-xl lg:text-2xl text-gray-200 italic font-light leading-relaxed mb-8 max-w-2xl">
                "{testimonialsData[activeIndex].content}"
              </blockquote>

              {/* Client detailed identity */}
              <div className="flex flex-col md:flex-row items-center gap-4 border-t border-white/5 pt-6 w-full justify-start md:justify-center">
                <div className="relative w-14 h-14 rounded-full overflow-hidden border border-white/10 shadow-[0_0_15px_rgba(139,92,246,0.2)]">
                  <img
                    src={testimonialsData[activeIndex].image}
                    alt={testimonialsData[activeIndex].name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover grayscale brightness-95"
                  />
                </div>
                <div className="flex flex-col text-left md:text-center">
                  <span className="font-display font-bold text-white text-base sm:text-lg">
                    {testimonialsData[activeIndex].name}
                  </span>
                  <span className="font-sans text-xs sm:text-sm text-gray-400 font-medium tracking-wide">
                    {testimonialsData[activeIndex].role} at <span className="text-electric-violet font-semibold">{testimonialsData[activeIndex].company}</span>
                  </span>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Carousel controls - Left arrow */}
          <button
            id="testimonial-control-prev"
            onClick={prevSlide}
            className="absolute left-0 md:-left-16 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white border border-white/10 transition-all cursor-pointer z-25 active:scale-90"
            aria-label="Previous slide"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          {/* Carousel controls - Right arrow */}
          <button
            id="testimonial-control-next"
            onClick={nextSlide}
            className="absolute right-0 md:-right-16 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white border border-white/10 transition-all cursor-pointer z-25 active:scale-90"
            aria-label="Next slide"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Carousel Indicator Dot Indicators */}
        <div id="testimonial-indicators-dots" className="flex items-center justify-center gap-2 mt-6">
          {testimonialsData.map((_, idx) => (
            <button
              key={idx}
              id={`testimonial-dot-${idx}`}
              onClick={() => setActiveIndex(idx)}
              className={`h-2.5 rounded-full transition-all duration-300 pointer-events-auto cursor-pointer ${
                activeIndex === idx ? 'w-8 bg-electric-violet' : 'w-2.5 bg-white/15 hover:bg-white/35'
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>

      </div>
    </section>
  );
}
