import { Atom, FileJson, Palette, Sparkles, Code, Server, Compass, GitBranch, Cloud, Layers } from 'lucide-react';
import { motion } from 'motion/react';
import { skillsCategories } from '../data';

// Custom card icon map
const getIcon = (name: string) => {
  switch (name) {
    case 'Atom': return Atom;
    case 'FileJson': return FileJson;
    case 'Palette': return Palette;
    case 'Sparkles': return Sparkles;
    case 'Code': return Code;
    case 'Server': return Server;
    case 'Compass': return Compass;
    case 'GitBranch': return GitBranch;
    case 'Cloud': return Cloud;
    case 'Layers': return Layers;
    default: return Code;
  }
};

export default function Skills() {
  return (
    <section
      id="skills"
      className="relative py-[80px] overflow-hidden bg-space-black"
    >
      <div className="absolute inset-0 bg-grid-pattern opacity-30 pointer-events-none" />

      {/* Decorative Orbs */}
      <div className="absolute top-[20%] left-[2%] w-[400px] h-[400px] bg-neon-blue/10 rounded-full filter blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[20%] right-[2%] w-[350px] h-[350px] bg-soft-pink/10 rounded-full filter blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        
        {/* Section Heading */}
        <div id="skills-section-heading" className="flex flex-col items-center text-center justify-center gap-4 mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EC4899]/15 border border-[#EC4899]/30">
            <span className="w-1.5 h-1.5 rounded-full bg-[#EC4899] animate-ping" />
            <span className="text-xs font-mono font-medium tracking-wide text-[#EC4899] uppercase">
              PROFICIENCIES & ENGINE
            </span>
          </div>

          <h2 className="font-display font-extrabold text-3xl sm:text-5xl tracking-tight text-white leading-tight">
            Advanced Tech Stack Lattices
          </h2>
          <p className="font-sans text-gray-400 text-base sm:text-lg max-w-2xl">
            My primary visual software ecosystems, ranging from high-FPS rendering pipelines to responsive interface patterns and infrastructure models.
          </p>
        </div>

        {/* Categories Grid */}
        <div id="skills-categories-wrapper" className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {skillsCategories.map((cat, catIdx) => (
            <motion.div
              key={catIdx}
              id={`skills-category-group-${catIdx}`}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6, delay: catIdx * 0.2 }}
              className="glass-panel p-6 sm:p-8 rounded-3xl border-white/5 bg-space-black/40 backdrop-blur-md relative"
            >
              {/* Corner ambient violet/blue flare */}
              <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${
                catIdx === 0 ? 'from-neon-blue/20' : 'from-soft-pink/20'
              } to-transparent opacity-30 filter blur-3xl pointer-events-none`} />

              {/* Category Header */}
              <h3 className="font-display font-bold text-xl sm:text-2xl text-white mb-8 border-b border-white/5 pb-4 flex items-center justify-between">
                <span>{cat.title}</span>
                <span className="text-xs font-mono text-gray-500 uppercase tracking-widest">
                  {cat.skills.length} Capabilities
                </span>
              </h3>

              {/* Skills Interactive List */}
              <div className="flex flex-col gap-6">
                {cat.skills.map((skill, sIdx) => {
                  const Icon = getIcon(skill.iconName);
                  return (
                    <div
                      key={sIdx}
                      id={`skill-item-${catIdx}-${sIdx}`}
                      className="group flex flex-col gap-2 p-4 rounded-2xl bg-white/[0.01] border border-white/5 hover:border-electric-violet/30 hover:bg-white/[0.02] hover:glow-purple transition-all duration-300"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-xl bg-white/5 text-gray-300 group-hover:text-white group-hover:bg-electric-violet/20 transition-all duration-300">
                            <Icon className="w-5 h-5 group-hover:rotate-6 transition-transform" />
                          </div>
                          <div className="flex flex-col text-left">
                            <span className="font-display font-semibold text-sm sm:text-base text-gray-200 group-hover:text-white transition-colors">
                              {skill.name}
                            </span>
                            <span className="font-sans text-xs text-gray-500 line-clamp-1">
                              {skill.description}
                            </span>
                          </div>
                        </div>
                        {/* Dynamic glow rating display */}
                        <div className="flex flex-col items-end">
                          <span className="font-mono text-xs text-gray-400 group-hover:text-neon-blue transition-colors font-semibold">
                            {skill.level}%
                          </span>
                        </div>
                      </div>

                      {/* Cool futuristic glow progress indicator */}
                      <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden mt-1 relative">
                        <motion.div
                          id={`skill-bar-${catIdx}-${sIdx}`}
                          initial={{ width: 0 }}
                          whileInView={{ width: `${skill.level}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 1, ease: 'easeOut' }}
                          className={`absolute inset-y-0 left-0 rounded-full bg-gradient-to-r ${
                            catIdx === 0 ? 'from-[#3B82F6] to-[#8B5CF6]' : 'from-[#8B5CF6] to-[#EC4899]'
                          }`}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
