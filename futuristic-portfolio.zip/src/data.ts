import { Project, SkillCategory, ExperienceItem, ServiceItem, TestimonialItem } from './types';

export const portfolioOwner = {
  name: "Alex Vance",
  title: "Principal Creative Technologist",
  subtitle: "Frontend Engineer / Interactions Expert",
  email: "alex@vance.io",
  phone: "+1 (415) 801-4492",
  location: "San Francisco, CA",
  aboutSummary: "I bridge the gap between complex software engineering and immersive visual design. For the past 1+ year, I’ve built ultra-performance interfaces, high-fidelity SaaS grids, dynamic data pipelines, and custom canvas products for some of the world's leading technology startups.",
  experienceYears: 1,
  projectsCompleted: 104,
  happyClients: 64,
  githubUrl: "https://github.com",
  linkedinUrl: "https://linkedin.com",
  twitterUrl: "https://twitter.com",
  dribbbleUrl: "https://dribbble.com",
  behanceUrl: "https://behance.com",
  instagramUrl: "https://instagram.com"
};

export const projectsData: Project[] = [
  {
    id: "aether-analytics",
    title: "Aether Analytics Suite",
    description: "Next-gen real-time cloud infrastructure observability platform with 3D canvas flow maps.",
    extendedDescription: "A fully custom dashboard engineered for Kubernetes clusters. Includes an optimized hardware-accelerated SVG flow map showing network package hops in real-time. Achieved less than 40ms payload streaming overhead over standard websockets.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80",
    tags: ["React 19", "Vite", "Recharts", "motion", "TailwindCSS"],
    demoUrl: "#",
    githubUrl: "#",
    featured: true,
    metrics: "12x metric streaming rate",
    category: "SaaS Platform"
  },
  {
    id: "nova-studio",
    title: "Nova 3D Shader Engine",
    description: "Multiplayer motion renderer and visual code workspace for modern physics systems on the web.",
    extendedDescription: "An in-browser code playhouse connecting interactive shader outputs directly to canvas-backed frames. Supports hot-module code reload, parameter mapping sliders, and automatic frame capture exports.",
    image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80",
    tags: ["WebGL", "Three.js", "React", "TypeScript", "TailwindCSS"],
    demoUrl: "#",
    githubUrl: "#",
    featured: true,
    metrics: "60 FPS interactive physics",
    category: "Creative Coding"
  },
  {
    id: "spectral",
    title: "Spectral Security Layer",
    description: "Encrypted packet tracker and secure transit network with decentralized routing visuals.",
    extendedDescription: "A premium cryptographic console visualizing decentralization routes. Displays real-time map projections with glow arcs representing tunnels, network load nodes, and packet speed status.",
    image: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=800&q=80",
    tags: ["D3.js", "Web Crypto API", "React", "Next.js"],
    demoUrl: "#",
    githubUrl: "#",
    featured: true,
    metrics: "99.999% encryption safety",
    category: "DevTools"
  },
  {
    id: "enigma-edge",
    title: "Enigma Federated ML Console",
    description: "No-code federated learning compiler visualizing neural connection lattices inside glass frames.",
    extendedDescription: "A highly complex software pipeline tool allowing direct model routing. Developers can wire layers, configure epochs, tune learning rates, and visualize predictions in clean high-contrast charts.",
    image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80",
    tags: ["TensorFlowJS", "D3", "React Canvas", "Vite"],
    demoUrl: "#",
    githubUrl: "#",
    featured: false,
    metrics: "0.2mb client footprint",
    category: "AI Infrastructure"
  }
];

export const skillsCategories: SkillCategory[] = [
  {
    title: "Frontend Engineering",
    skills: [
      { name: "React / React 19", iconName: "Atom", level: 95, description: "Advanced patterns, performance tuning, and hooks" },
      { name: "TypeScript", iconName: "FileJson", level: 92, description: "Strict static typing, complex interfaces, and utility compilation" },
      { name: "Tailwind CSS", iconName: "Palette", level: 98, description: "Custom theme creation, responsive design, and fluid grids" },
      { name: "motion (Framer)", iconName: "Sparkles", level: 90, description: "Complex timeline sequences, layout transitions, physics triggers" },
      { name: "HTML5 / Canvas", iconName: "Code", level: 92, description: "Pixel-perfect templates, custom high-performance WebGL context" }
    ]
  },
  {
    title: "Backend & Tooling",
    skills: [
      { name: "Node.js & Express", iconName: "Server", level: 85, description: "High-throughput API routing and server-side socket pipelines" },
      { name: "D3.js & Charting", iconName: "Compass", level: 88, description: "Intricate data visualization, geographic projections, customized shapes" },
      { name: "Git & GitHub Actions", iconName: "GitBranch", level: 90, description: "Version control, scalable automated test configurations, deploy rules" },
      { name: "Vercel & Netlify", iconName: "Cloud", level: 92, description: "Edge routing, environment secrets, analytics syncing" },
      { name: "Figma UI/UX Studio", iconName: "Layers", level: 86, description: "Iterative wireframing, high-contrast visual standards, micro-alignment" }
    ]
  }
];

export const experienceTimeline: ExperienceItem[] = [
  {
    id: "exp-1",
    role: "Lead Creative Interaction Engineer",
    company: "Zeta AI Platforms",
    logoLetter: "Z",
    period: "2024 - Present",
    description: "Directing the modular styling engine for ZS3 core models. Designing full-fidelity visual consoles and vector charts.",
    highlights: [
      "Engineered high-performance React flow editor used by 45,000 developer subscribers.",
      "Optimized client-side frame rendering, cutting memory consumption by 34%.",
      "Mentored a junior frontend crew of 6, establishing unified CSS variables standards."
    ],
    type: "job"
  },
  {
    id: "exp-2",
    role: "Senior UX Architect & Developer",
    company: "Linear Stream Studio",
    logoLetter: "L",
    period: "2022 - 2024",
    description: "Coded dynamic dashboards, glass layout features, and system activity logs trackers.",
    highlights: [
      "Crafted full-stack real-time telemetry panels supporting multiple server channels.",
      "Won the internal creative engineering award for an interactive, glowing visual network representation.",
      "Spearheaded complete migration from legacy CSS modules to tailwind utility classes."
    ],
    type: "job"
  },
  {
    id: "exp-3",
    role: "Interactive Design Consultant",
    company: "Freelance Creative",
    logoLetter: "F",
    period: "2020 - 2022",
    description: "Delivered highly stylized, bespoke marketing canvases and landing pages for progressive SaaS companies.",
    highlights: [
      "Designed and deployed 40+ responsive landing cards featuring smooth WebGL transitions.",
      "Collaborated direct with founders to wire up clean, accessible, modern SaaS themes.",
      "Consistently achieved >95 LightHouse metrics on mobile and desktop layout deployments."
    ],
    type: "freelance"
  },
  {
    id: "exp-4",
    role: "B.S. in Computer Science & Interaction Design",
    company: "Academy of Interactive Arts",
    logoLetter: "A",
    period: "2016 - 2020",
    description: "Focused on computer visualization, software physics pipelines, typography design, and cognitive human-computer ergonomics.",
    highlights: [
      "Graduated with High Honors (GPA: 3.92).",
      "Published conference thesis on hardware-accelerated browser animation metrics.",
      "Recipient of the National Merit Arts & Engineering Fellowship."
    ],
    type: "education"
  }
];

export const servicesData: ServiceItem[] = [
  {
    id: "serv-webdev",
    title: "Premium Web Engineering",
    description: "We build pixel-perfect, highly scalable, responsive React / Next.js web systems powered by fast compilations.",
    iconName: "Code",
    gradient: "from-[#3B82F6] to-[#8B5CF6]",
    features: ["Responsive layouts", "TypeScript static safety", "LightHouse 95+ score", "SEO & metadata optimization"]
  },
  {
    id: "serv-uiux",
    title: "Immersive UI/UX Arts",
    description: "Fidelity wireframes, state micro-interactions, dark elegant patterns, and precise typography selections.",
    iconName: "Palette",
    gradient: "from-[#8B5CF6] to-[#EC4899]",
    features: ["Adaptive Figma files", "Micro-interaction triggers", "Strict layout grids", "Typography system construction"]
  },
  {
    id: "serv-viz",
    title: "Interactive Analytics & Canvas",
    description: "Hardware accelerated canvas engines, detailed D3 nodes, abstract timelines, and physics-based particle sets.",
    iconName: "Sparkles",
    gradient: "from-[#EC4899] to-[#FB923C]",
    features: ["Optimized SVG projections", "Physics particle emitters", "Dynamic color map fields", "Ultra fluid WebGL loops"]
  }
];

export const testimonialsData: TestimonialItem[] = [
  {
    id: "test-1",
    name: "Eleanor Vance",
    role: "Chief of Product",
    company: "Aura Labs",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150&q=80",
    content: "Alex completely transformed how we build digital interfaces. Creative developers with his level of rigorous technical competence are extremely hard to find.",
    rating: 5
  },
  {
    id: "test-2",
    name: "Marcus Sterling",
    role: "Co-Founder & CTO",
    company: "Vortex Platform",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150&q=80",
    content: "Our core dashboard rewrite with Alex achieved solid 60 FPS charts with massive data clusters. His taste in aesthetic composition is absolutely spotless.",
    rating: 5
  },
  {
    id: "test-3",
    name: "Sophia Martinez",
    role: "Creative Director",
    company: "Velo Motion Digital",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80",
    content: "Alex doesn't just write code, he crafts experiences. The micro-animations he implemented on our corporate landing page increased user engagement by 42%.",
    rating: 5
  }
];
